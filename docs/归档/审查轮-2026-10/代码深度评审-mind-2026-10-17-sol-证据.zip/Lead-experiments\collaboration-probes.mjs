import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Org } from '../dsh-mind/src/org.js';
import { runAction } from '../dsh-mind/lib/actions.js';
import { 全员已交 } from '../dsh-mind/src/tasks.js';
const root = fileURLToPath(new URL(`./collaboration-${Date.now()}/`, import.meta.url));
const priv = join(root, 'private');
await mkdir(join(priv, '身份档案'), { recursive: true });
const members = Object.fromEntries(['a','b','c','d','r'].map(id => [id, { id, 岗位: id === 'r' ? '复核员' : id === 'd' ? '文档整理' : '插件工程', 代: 1, status: '在岗' }]));
await writeFile(join(priv, '身份档案/identity.json'), JSON.stringify({ members, sovereign: { lastInteraction: new Date().toISOString() }, denylist: [] }));
await mkdir(join(priv, '集体L2-共享基础设施/defaults'), { recursive: true });
await writeFile(join(priv, '集体L2-共享基础设施/defaults/部署.json'), JSON.stringify({ 会审讨论: { 每轮消息上限: 1 } }));
const org = await Org.open({ home: root, privateRoot: priv, factoryRoot: fileURLToPath(new URL('../dsh-mind/mind/', import.meta.url)), project: 'p', random: () => 0 });
if (!org.policy.healthy) throw Error('fixture policy unhealthy');
const L = { id: 'lead', kind: 'Lead' }, A = { id: 'a', kind: '成员' }, B = { id: 'b', kind: '成员' }, C = { id: 'c', kind: '成员' }, D = { id: 'd', kind: '成员' }, R = { id: 'r', kind: '成员' };
const act = (主体, action, args = {}) => runAction({ org, 项目: 'p', 主体, args: { action, ...args } });
let seq = 0;
async function task(owners = ['a','b'], mode = '独立会审') {
  const { 节点: n } = await act(L, 'task_create', { 描述: `Bprobe-${++seq}`, 负责人: owners, 判据: ['probe'], 模式: mode });
  await act(L, 'task_dispatch', { id: n.id });
  await act(A, 'task_start', { id: n.id });
  return n.id;
}
const submit = (who, id, label = 'X', extra = {}) => act(who, 'task_submit', { id, 结论: `answer-${label}`, 结论层: label, ...extra });
const result = { root };
{
  const id = await task(); await submit(A, id);
  const pre = await org.tasks.get(id, { 项目: 'p' });
  await act(R, 'task_review', { id, 三态: '过' });
  result.partialAccept = { beforeAnswers: pre.独立答案.length, owners: pre.负责人.length, after: (await org.tasks.get(id, { 项目: 'p' })).状态 };
}
{
  const id = await task(); await submit(A, id, 'X');
  const final = await submit(B, id, 'Y'); await submit(B, id, 'X');
  result.rewriteAfterReveal = { finalSubmitSawA: final.节点.独立答案.find(a => a.成员 === 'a')?.结论, after: (await org.tasks.get(id, { 项目: 'p' })).独立答案 };
}
{
  const id = await task(['a'], null); await submit(A, id);
  const append = org.audit.append.bind(org.audit);
  org.audit.append = async row => { if (row.对象?.id === id && row.结果 === 'reviewed') throw Error('injected review audit failure'); return append(row); };
  let code; try { await act(R, 'task_review', { id, 三态: '不过' }); } catch (e) { code = e.code; } finally { org.audit.append = append; }
  const n = await org.tasks.get(id, { 项目: 'p' });
  await act(R, 'task_review', { id, 三态: '过' });
  result.rejectCrash = { code, failedState: n.状态, epoch: n.代, answers: n.独立答案.length, rejects: n.打回次数, withoutRework: (await org.tasks.get(id, { 项目: 'p' })).状态 };
}
{
  const id = await task(); await submit(A, id); await submit(B, id); await act(L, 'debate_open', { id });
  await act(A, 'debate_say', { id, 类型: '表态', 内容: 'old' });
  await act(R, 'task_review', { id, 三态: '不过' }); await act(A, 'task_start', { id }); await submit(A, id); await submit(B, id); await act(L, 'debate_open', { id });
  let blocked; try { await act(A, 'debate_say', { id, 类型: '表态', 内容: 'new' }); } catch (e) { blocked = { rule: e.rule, message: e.message }; }
  result.oldBudget = { epoch: (await org.tasks.get(id, { 项目: 'p' })).代, blocked };
}
{
  const id = await task(['a','b','c']); await submit(A, id); await submit(B, id);
  const n = await org.tasks.get(id, { 项目: 'p' });
  result.reviewZeroBlind = { allSubmitted: 全员已交(n), response: await act(C, 'review_zero', { id }) };
}
{
  await act(L, 'bus_send', { project: 'q', 线程: 'internal-q', 类型: '表态', 内容: 'B-SECRET-Q' });
  result.crossProjectRead = await act(C, 'bus_read', { project: 'q', 线程: 'internal-q' });
}
{
  const id = await task(['插件工程','文档整理']); await submit(A, id); await submit(D, id);
  const n = await org.tasks.get(id, { 项目: 'p' });
  let unlock; try { unlock = await act(L, 'bus_unlock', { id, 线程: id }); } catch (e) { unlock = { rule: e.rule, message: e.message }; }
  result.roleAddress = { owners: n.负责人, authors: n.独立答案.map(a => a.成员), allSubmitted: 全员已交(n), unlock };
}
{
  const id = await task(); await submit(A, id); await submit(B, id); await act(L, 'debate_open', { id }); await act(R, 'task_review', { id, 三态: '过' });
  let response; try { response = await act(A, 'debate_say', { id, 类型: '表态', 内容: 'after-accept' }); } catch (e) { response = { denied: e.name, rule: e.rule, message: e.message }; }
  result.terminalSay = { state: (await org.tasks.get(id, { 项目: 'p' })).状态, response };
}
await writeFile(new URL('./collaboration-evidence.json', import.meta.url), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
