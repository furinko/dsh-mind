import assert from 'node:assert/strict';
import { writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { Org } from '../dsh-mind/src/org.js';
import { runAction } from '../dsh-mind/lib/actions.js';
const root = fileURLToPath(new URL(`./wiring-${Date.now()}/`, import.meta.url));
const factoryRoot = fileURLToPath(new URL('../dsh-mind/mind/', import.meta.url));
const org = await Org.open({ home: root, privateRoot: root + 'private', factoryRoot, project: 'p' });
const L = { id: 'lead', kind: 'Lead' }, A = { id: 'a', kind: '成员' }, B = { id: 'b', kind: '成员' };
const act = (主体, action, args = {}) => runAction({ org, 项目: 'p', 主体, args: { action, ...args } });
await org.registry.assign({ subject: L, 岗位: '插件工程', 实例: A.id });
await org.registry.assign({ subject: L, 岗位: '插件工程', 实例: B.id });
const out = {};
{
  const n = (await act(L, 'task_create', { 描述: 'zero divergence wiring', 负责人: ['a','b'], 判据: ['probe'], 模式: '独立会审' })).节点;
  await act(L, 'task_dispatch', { id: n.id }); await act(A, 'task_start', { id: n.id });
  await act(A, 'task_submit', { id: n.id, 结论: 'different wording A', 结论层: 'X' });
  await act(B, 'task_submit', { id: n.id, 结论: 'different wording B', 结论层: 'X' });
  await act(L, 'task_review', { id: n.id, 三态: '过' }); await act(L, 'task_settle', { id: n.id });
  const before = (await org.audit.read({})).filter(x => x.动作 === '零分歧异常').length;
  const check = await act(L, 'review_zero', { id: n.id });
  const after = (await org.audit.read({})).filter(x => x.动作 === '零分歧异常').length;
  assert.equal(before, 0); assert.equal(after, 1); out.zeroDivergence = { afterFullLifecycle: before, afterOptionalAction: after, check };
}
{
  await mkdir(org.layout.private('集体L2-共享基础设施', 'defaults'), { recursive: true });
  await writeFile(org.layout.guardReceiptFile(), JSON.stringify({ 范围闸: { registered: true }, 调度创建闸: { registered: true } }));
  const green = await org.probes.run({ subject: L, 机制版本: 'known-installable-green' }); assert.equal(green.全绿, true);
  await writeFile(org.layout.guardReceiptFile(), JSON.stringify({ 范围闸: { registered: false }, 调度创建闸: { registered: true } }));
  const red = await org.probes.run({ subject: L }); assert.equal(red.全绿, false);
  const before = (await org.audit.read({})).filter(x => x.动作 === '自动回滚').length;
  const manual = await org.probes.autoRollback();
  const after = (await org.audit.read({})).filter(x => x.动作 === '自动回滚').length;
  assert.equal(before, 0); assert.equal(after, 1);
  out.probeRecovery = { greenVersion: green.机制版本, redVersion: red.机制版本, redProbes: red.见红, automaticRows: before, manual, afterManualRows: after };
}
{
  const n = (await act(L, 'task_create', { 描述: 'artifact visibility', 负责人: ['a','b'], 判据: ['probe'], 模式: '独立会审' })).节点;
  await act(L, 'task_dispatch', { id: n.id }); await act(A, 'task_start', { id: n.id });
  await act(A, 'task_submit', { id: n.id, 结论: 'secret A', 结论层: 'X', 产出物引用: ['artifact-SECRET-A'] });
  const response = await act(B, 'task_pending', { id: n.id, 原因: 'waiting' });
  assert.equal(response.节点.独立答案.length, 0); assert.ok(response.节点.产出物引用.includes('artifact-SECRET-A'));
  out.blindArtifact = { ownAnswersVisible: response.节点.独立答案.length, aggregateArtifacts: response.节点.产出物引用 };
}
{
  const card = await org.registry.get({ id: '插件工程' });
  out.roleInstructions = { keys: Object.keys(card.段), actualRuleLength: card.段.个体L1.length, memberSpawnRuleLength: (card.段['个体L1 · 规则'] ?? '').length };
  await mkdir(org.layout.roleCardDir('私有'), { recursive: true });
  await writeFile(org.layout.roleCardDir('私有') + '/插件工程.md', '---\nid: 插件工程\nkind: 身份\nauthority: 自治\nzone: 私有\ndomain: 个体\nversion: 1\n---\n# 插件工程\n\n## 个体L3 · 经验引用\n- probe-experience\n');
  out.registryProjection = { effectiveRefs: (await org.registry.get({ id: '插件工程' })).能力引用, listedRefs: (await org.registry.list()).find(x => x.id === '插件工程').能力引用 };
}
{
  const sent = await act(L, 'bus_send', { 线程: 'reserved-lead-message', 类型: '表态', 内容: 'deferred workflow', 暂不投递: true });
  const delivered = await act(B, 'bus_deliver', { 线程: 'reserved-lead-message', id: sent.消息.id });
  out.unrelatedDeliver = { sender: 'lead', actor: 'b', delivered };
}
await writeFile(new URL('./wiring-evidence.json', import.meta.url), JSON.stringify(out, null, 2));
console.log(JSON.stringify(out, null, 2));
