import { writeFile } from 'node:fs/promises';
import * as h from '../dsh-mind/components/board/test/client-harness.mjs';
const evidence = {};
async function boot({ view = h.sampleView(), sessions = h.makeSessions([{ id: 's', main: true }]), fetch: fn } = {}) {
  const calls = [];
  const loaded = h.loadClient({ fetch: (url, init) => { calls.push({ url, init }); return fn ? fn(url, init) : h.jsonResponse(url.includes('workbench') ? { 成功: true, 数据: view } : { 成功: true, 读数: { 失联限制: true, 生效响应期限小时: 72, lost: false } }); } });
  const plugin = loaded.definition.factory(h.makeStrictRequire().require), slots = h.makeSlots();
  const dispose = plugin.apply(h.makeCtx({ slots: slots.slots, sessions }));
  return { calls, loaded, dispose, component: name => slots.calls.register.find(r => r.options.name === name).Component };
}
{
  const a = await boot({ sessions: h.makeSessions([]) }), r = h.createRenderer(a.component('settings.section'), {});
  r.flush(); await h.settle(); r.flush();
  evidence.noSession = { requests: a.calls.map(x => x.url), presenceRequested: a.calls.some(x => x.url.includes('/presence')), text: h.collect(r.tree, { skipStyle: true }).text.match(/未接入[^\n]*/g) };
  r.unmount(); a.dispose();
}
{
  const view = h.sampleView();
  view.待你决定 = Array.from({ length: 10 }, (_, i) => ({ 类型: '待决项', 节点: 'pending-' + i, 描述: 'DECISION-' + i, 原因: 'test', 命令: '/mind status' }));
  view.会审 = Array.from({ length: 6 }, (_, i) => ({ ...view.会审[1], 节点: 'review-' + i, 描述: 'REVIEW-' + i }));
  const b = await boot({ view }); await h.settle(); const r = h.createRenderer(b.component('main'), {});
  r.flush(); await h.settle(); r.flush(); const text = h.collect(r.tree, { skipStyle: true }).text;
  evidence.truncation = { decision7: text.includes('DECISION-7'), decision8: text.includes('DECISION-8'), review3: text.includes('REVIEW-3'), review4: text.includes('REVIEW-4'), moreButtons: h.collect(r.tree).elements.filter(x => x.type === 'button').map(x => h.collect(x, { skipStyle: true }).text).filter(x => /另有|全部|更多/.test(x)) };
  r.unmount(); b.dispose();
}
{
  let hours = 72;
  const c = await boot({ fetch: (url, init) => {
    if (url.includes('workbench')) return h.jsonResponse({ 成功: true, 数据: h.sampleView() });
    if (url.includes('delegation')) return h.jsonResponse({ 成功: false, 理由: 'unused' });
    if (init.method === 'POST') { hours = JSON.parse(init.body).小时; return new Promise(() => {}); }
    return h.jsonResponse({ 成功: true, 读数: { 失联限制: true, 生效响应期限小时: hours, lost: false } });
  } });
  const r = h.createRenderer(c.component('settings.section'), {}); r.flush(); await h.settle(); r.flush();
  h.collect(r.tree).elements.find(x => x.props['aria-label'] === '响应期限小时').props.onChange({ target: { value: '168' } }); r.flush();
  h.collect(r.tree).elements.find(x => x.type === 'button' && x.props.children === '保存').props.onClick();
  await h.settle(); c.loaded.timers.fireTimeouts(); await h.settle(); r.flush();
  evidence.unknownPost = { serverHours: hours, postCount: c.calls.filter(x => x.init.method === 'POST').length, requestsAfterPost: c.calls.slice(c.calls.findIndex(x => x.init.method === 'POST')).map(x => x.init.method + ' ' + x.url), message: h.collect(r.tree, { skipStyle: true }).text.match(/没写进去[^\n]*/g) };
  r.unmount(); c.dispose();
}
{
  let release;
  const d = await boot({ fetch: url => url.includes('workbench') ? new Promise(r => { release = r; }) : h.jsonResponse({ 成功: true, 读数: { 失联限制: true, 生效响应期限小时: 72, lost: false } }) });
  d.dispose(); const before = d.loaded.store.size;
  release(h.jsonResponse({ 成功: true, 数据: h.sampleView() })); await h.settle();
  evidence.disposedResponse = { cacheBefore: before, cacheAfter: d.loaded.store.size };
}
await writeFile(new URL('./client-evidence.json', import.meta.url), JSON.stringify(evidence, null, 2));
console.log(JSON.stringify(evidence, null, 2));
