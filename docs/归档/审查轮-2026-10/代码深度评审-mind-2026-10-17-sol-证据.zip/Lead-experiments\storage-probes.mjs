import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { makeFixture, LEAD, SOVEREIGN } from '../dsh-mind/test/helpers.mjs';
import { MemoryService } from '../dsh-mind/src/memory.js';
import { ObjectStore } from '../dsh-mind/src/store.js';
const evidence = {};
async function fixture() { const f = await makeFixture(); if (!f.policy.healthy) throw new Error('fixture unhealthy'); return f; }
const remember = (memory, content) => memory.remember({ subject: LEAD, 类: '知识', 内容: content, 来源: 'isolated review observation', 项目: 'A' });
{
  const f = await fixture(), memory = new MemoryService(f);
  const source = await remember(memory, 'orchid privacy sample');
  let release, entered;
  const gate = new Promise(r => { release = r; }), seen = new Promise(r => { entered = r; });
  const check = f.policy.check.bind(f.policy);
  f.policy.check = async input => {
    if (input.action === 'write' && input.target.id === '记忆/跨项目/知识' && input.context?.id === source.id) { entered(); await gate; }
    return check(input);
  };
  const promotion = memory.promoteCrossProject(source.id, { subject: LEAD, 岗位: '插件工程', 理由: 'reuse' });
  await Promise.race([seen, new Promise((_, reject) => setTimeout(() => reject(new Error('promotion barrier not reached')), 3000))]);
  const deletion = await new MemoryService(f).purge(source.id, { subject: LEAD, 敏感: true, 理由: 'remove sensitive source' });
  release(); await promotion; f.policy.check = check;
  const query = await new MemoryService(f).query({ subject: LEAD, 项目: 'B', 岗位: '插件工程', 文本: 'orchid' });
  assert.equal(deletion.已删除, true); assert.equal(query.命中.length, 1);
  evidence.promoteAfterPurge = { home: f.home, deletion, query };
}
{
  const f = await fixture(), memory = new MemoryService(f);
  const source = await remember(memory, 'bromeliad erase sample');
  const file = f.layout.memoryLog('A', '知识');
  await writeFile(file, '\ufeff' + await readFile(file, 'utf8'));
  const deletion = await new MemoryService(f).purge(source.id, { subject: LEAD, 敏感: true, 理由: 'erase BOM encoded row' });
  const raw = await readFile(file, 'utf8');
  assert.equal(deletion.已删除, true); assert.equal(raw.includes('bromeliad erase sample'), true);
  evidence.bomPurge = { home: f.home, deletion, sourceContentStillPresent: raw.includes('bromeliad erase sample') };
}
{
  const f = await fixture(), memory = new MemoryService(f);
  const source = await remember(memory, 'violet obsolete account');
  await memory.promoteCrossProject(source.id, { subject: LEAD, 岗位: '插件工程', 理由: 'reuse' });
  const replacement = await memory.overturn(source.id, { subject: LEAD, 新条目: 'corrected current description', 理由: 'old claim falsified' });
  const own = await new MemoryService(f).query({ subject: LEAD, 项目: 'A', 岗位: '插件工程', 文本: 'violet' });
  const other = await new MemoryService(f).query({ subject: LEAD, 项目: 'B', 岗位: '插件工程', 文本: 'violet' });
  assert.equal(own.命中.length, 0); assert.equal(other.命中.length, 1);
  evidence.overturnedCrossProjectCopy = { home: f.home, replacement, ownHits: own.命中.length, otherProjectHits: other.命中 };
}
{
  const f = await fixture(), store = new ObjectStore(f), id = 'shared-history-id';
  const doc = text => ({ meta: { id, authority: '自治', domain: '集体' }, body: `# ${id}\n\n## 适用岗位\n- 插件工程\n\n## 怎么做\n${text}\n` });
  await store.write('能力', doc('private-v1'), { subject: LEAD, reason: 'first private' });
  await store.write('能力', doc('private-v2'), { subject: LEAD, reason: 'second private' });
  const before = await store.readVersion(id, 1);
  const factory = { id: 'factory', kind: '出厂作者' };
  await store.write('能力', doc('factory-v1'), { subject: factory, zone: '出厂', reason: 'first factory' });
  await store.write('能力', doc('factory-v2'), { subject: factory, zone: '出厂', reason: 'second factory' });
  const after = await store.readVersion(id, 1);
  await store.rollback('能力', id, 1, { subject: SOVEREIGN, reason: 'restore private first version' });
  const current = await store.read('能力', id, { subject: LEAD, zone: '私有' });
  assert.match(before, /private-v1/); assert.match(after, /factory-v1/); assert.match(current.body, /factory-v1/);
  evidence.historyCollision = { home: f.home, before, after, privateRollbackBody: current.body };
}
await writeFile(new URL('./storage-evidence.json', import.meta.url), JSON.stringify(evidence, null, 2));
console.log(JSON.stringify(evidence, null, 2));
