import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { Org } from '../dsh-mind/src/org.js';
import { runAction } from '../dsh-mind/lib/actions.js';
const root = fileURLToPath(new URL('./data/', import.meta.url));
const factoryRoot = fileURLToPath(new URL('../dsh-mind/mind/', import.meta.url));
const lead = { id: 'lead-probe', kind: 'Lead', roleId: 'Lead' };
const output = [];
async function open(name) {
  const home = root + name;
  await mkdir(home, { recursive: true });
  return Org.open({ home, factoryRoot, privateRoot: home + '/private', project: 'audit', logger: { info() {}, warn() {} } });
}
function call(org, subject, args) { return runAction({ org, 项目: 'audit', 主体: subject, args }); }
async function newTask(org, description, owners = [lead.id], mode) {
  return (await call(org, lead, { action: 'task_create', 描述: description, 负责人: owners, 判据: ['observable result'], ...(mode ? { 模式: mode } : {}) })).节点;
}
async function ready(org, node) {
  await call(org, lead, { action: 'task_dispatch', id: node.id });
  await call(org, lead, { action: 'task_start', id: node.id });
  await call(org, lead, { action: 'task_submit', id: node.id, 结论: 'producer result' });
}
{
  const org = await open('precheck');
  const member = { id: 'member-probe', kind: '成员' };
  await org.registry.assign({ subject: lead, 岗位: '插件工程', 实例: member.id });
  const node = await newTask(org, 'member preflight', [member.id]);
  await call(org, lead, { action: 'task_dispatch', id: node.id });
  await call(org, member, { action: 'task_start', id: node.id });
  const target = { id: 'artifact-probe', kind: '产物', authority: '自治', zone: '私有' };
  const viaAction = await call(org, member, { action: 'policy_check', 动作: 'write', target: { ...target, task: node.id, sandbox: true }, 任务: node.id });
  const direct = await org.policy.decide({ subject: member, action: 'write', target, context: { task: await org.tasks.get(node.id, { 项目: 'audit' }) } });
  assert.equal(viaAction.判定.verdict, 'deny');
  assert.equal(direct.verdict, 'allow');
  output.push({ probe: 'member-policy-precheck-drops-task', action: viaAction.判定, directWithAuthoritativeTask: direct });
}
{
  const org = await open('authorization-reference');
  const ordinary = await newTask(org, 'ordinary non authorization task');
  const exempt = await call(org, lead, { action: 'review_exempt', id: ordinary.id, 授权引用: 'task-never-existed', 原因: 'probe has no human approval' });
  assert.equal(exempt.节点.复核豁免.授权引用, 'task-never-existed');
  const appointed = await call(org, lead, { action: 'registry_assign', 岗位: '复核员', 实例: 'invented-reviewer', 授权引用: ordinary.id });
  assert.equal(appointed.实例.状态, '在岗');
  output.push({ probe: 'reference-is-not-authorization', nonexistentReferenceExemption: exempt.节点.复核豁免, ordinaryTaskReviewerAppointment: appointed });
}
{
  const org = await open('review-signature');
  const node = await newTask(org, 'review attribution');
  await ready(org, node);
  let denied = null;
  try { await call(org, lead, { action: 'task_review', id: node.id, 三态: '过' }); } catch (e) { denied = { name: e.name, message: e.message }; }
  assert.equal(denied?.name, 'Denied');
  const accepted = await call(org, lead, { action: 'task_review', id: node.id, 三态: '过', 复核者: 'not-a-registered-reviewer' });
  const latest = await org.tasks.get(node.id, { 项目: 'audit' });
  assert.equal(latest.状态, '已采纳');
  output.push({ probe: 'producer-can-counter-sign-as-fictional-reviewer', defaultSignature: denied, inventedSignature: accepted, nodeState: latest.状态, reviewer: latest.复核者 });
}
console.log(JSON.stringify({ baseline: 'frozen worktree 181341a plus WIP', output }, null, 2));
