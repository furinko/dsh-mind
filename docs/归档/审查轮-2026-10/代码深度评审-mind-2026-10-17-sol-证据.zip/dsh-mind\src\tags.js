/**
 * 授权标签与正文结构（§4 授权标签、§6 对象元数据、§11 写入侧校验）。
 *
 * 一条纪律（§4）：**目录负责「找得到」，标签负责「谁能改」**。
 * 所以本文件是「谁能改」的唯一解析处——策略引擎只读这里的结论，不看路径。
 *
 * 标签是**段**粒度的：同一份文档里，权限矩阵那段可以是「法律」，
 * 作业规程那段可以是「自治」。对象级 authority = 各段中最高的那个。
 */
import { InvalidBody } from './kernel/errors.js';
import { splitClauses } from './kernel/text.js';

/** 授权档的强弱，用于「冲突时以更高 authority 为准」（§4）。 */
export const AUTHORITY_RANK = { 宪章: 3, 法律: 2, 自治: 1, 只增: 0 };

/** §6 `kind` 的封闭清单。 */
export const KINDS = ['身份', '规则', '能力', '知识', '经历', '偏好', '作答', '任务', '消息', '产物', '账目'];

/** §6 `authority` 的封闭清单。 */
export const AUTHORITIES = ['宪章', '法律', '自治', '只增'];

/** 段标记：`<!-- authority: 法律 -->`，写在段首。 */
const SEGMENT_MARKER = /^<!--\s*authority\s*:\s*(宪章|法律|自治|只增)\s*-->\s*$/;

/**
 * @param {string} a
 * @param {string} b
 * @returns {number} 正数表示 a 更强
 */
export function compareAuthority(a, b) {
  return (AUTHORITY_RANK[a] ?? -1) - (AUTHORITY_RANK[b] ?? -1);
}

/**
 * @param {string[]} list
 * @param {string} [fallback]
 * @returns {string} 最强的那一档
 */
export function highestAuthority(list, fallback = '自治') {
  let best = fallback;
  for (const item of list) {
    if (compareAuthority(item, best) > 0) best = item;
  }
  return best;
}

/**
 * 剥离行内注释：`#` 前要有空白（或它在行首），且**不许切进引号内**。
 *
 * 为什么不能继续用 `/\s+#.*$/`（W3 批2·2026-10-09）：`摘要: "a # b"` 会被切成
 * `摘要: "a` —— 值被静默改坏，而且坏得很隐蔽（`unquote` 认不出没闭合的引号，
 * 于是存进 meta 的是带半个引号的字符串，谁也不报错）。`#` 在引号里就是值的一部分。
 *
 * 转义引号也要认（W3 批3·2026-10-09）：`"a \" b" # 注释` 里那个 `\"` 不结束引号——
 * 否则扫描器会在它那里"闭合"，又被后面那个真正的 `"` 重新打开 ⇒ 行尾注释反而被当值留下，
 * 于是注释文本混进 meta（`unquote` 再怎么解转义也救不回来）。
 *
 * @param {string} line
 * @returns {string}
 */
function stripInlineComment(line) {
  let quote = null;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quote) {
      if (ch === '\\') {
        i += 1; // 转义：下一个字符是值的一部分（哪怕它长得像引号）
        continue;
      }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      continue;
    }
    if (ch === '#' && (i === 0 || /\s/.test(line[i - 1]))) return line.slice(0, i);
  }
  return line;
}

/**
 * 解析极小 YAML 子集（对象元数据只有标量与短列表，不需要完整 YAML）。
 *
 * 为什么不用 YAML 依赖：§12.5「出厂件不含任何用户特定信息」之外还有一条现实约束——
 * 插件要在没有安装步骤的情况下被宿主直接 import。零依赖是最强的可装载性保证。
 *
 * 入口先归一换行（W3 批2·2026-10-09）：CRLF 文本按 `\n` 切行后每行尾部留着 `\r`，
 * 会让 `id: 宪章\r` 这种值带着回车进 meta（比对、路径、哈希全跟着错）。
 * 只归一**读入**；写出仍走 LF（`formatFrontMatter`），字节稳定性不受影响。
 *
 * @param {string} raw front matter 内部文本（不含 `---` 行）
 * @returns {{ data: Record<string, any>, errors: string[] }}
 */
export function parseSimpleYaml(raw) {
  /** @type {Record<string, any>} */
  const data = {};
  const errors = [];
  for (const rawLine of String(raw).replace(/\r\n?/g, '\n').split('\n')) {
    const line = stripInlineComment(rawLine).trimEnd();
    if (!line.trim() || line.trim().startsWith('#')) continue;
    // 键允许中文：对象元数据里有 `名`、`摘要` 这类人读字段，
    // 只认 ASCII 会让它们**静默丢失** —— 那比报错更难查。
    const m = /^([\p{Letter}_][\p{Letter}\p{Number}_-]*)\s*:\s*(.*)$/u.exec(line);
    if (!m) {
      errors.push(`无法解析的元数据行：${line.trim()}`);
      continue;
    }
    const [, key, rest] = m;
    const value = rest.trim();
    if (value.startsWith('[') && value.endsWith(']')) {
      data[key] = splitArrayItems(value.slice(1, -1));
    } else if (value === 'null') {
      // 与写侧对称（2026-10-14 审查 P3）：formatFrontMatter 把 null 写成 `null` 字面量，
      // 读回来必须还是 null——修前 null 落成空值、读回 []，往返漂移。
      data[key] = null;
    } else if (value === '') {
      data[key] = []; // legacy：老账里空值行的原义（写侧现已只对 undefined 落空值）
    } else {
      data[key] = unquote(value);
    }
  }
  return { data, errors };
}

/**
 * 切分数组字面量的内部文本：**逗号只在引号外才算分隔符**（W3 批4·2026-10-09）。
 *
 * 为什么必须这样：写侧现在会把含逗号的元素引号化成 `["a,b", c]`；按逗号裸切会得到
 * `["a` / `b"` / `c]` 三段——`unquote` 认不出没闭合的引号，于是 meta 里出现半截引号串，
 * 而 errors 还是空的（静默改坏）。切分与引号规则必须成对，否则修了一半等于没修。
 *
 * **空元素的折中**（W3 批5·2026-10-09）：只丢**不带引号**的空元素，带引号的空串保留。
 *  - `[a, , b]`（legacy 手写）⇒ 空段照旧丢掉 → `['a','b']`（老行为不变）；
 *  - `[""]`（写侧对空串的表示）⇒ 保留成 `['']`（往返闭合）。
 * 一律丢会让 `['']` 往返成 `[]`（复核反例）；一律留会让 legacy 的 `a, ,b` 多出一个空串。
 *
 * @param {string} raw 不含外层 `[` `]` 的文本
 * @returns {string[]}
 */
function splitArrayItems(raw) {
  /** @type {Array<{text: string, quoted: boolean}>} */
  const 段 = [];
  let 当前 = '';
  let 见过引号 = false;
  let quote = null;
  for (let i = 0; i < raw.length; i += 1) {
    const ch = raw[i];
    if (quote) {
      当前 += ch;
      if (ch === '\\') {
        if (i + 1 < raw.length) {
          当前 += raw[i + 1];
          i += 1;
        }
        continue;
      }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      见过引号 = true;
      当前 += ch;
      continue;
    }
    if (ch === ',') {
      段.push({ text: 当前, quoted: 见过引号 });
      当前 = '';
      见过引号 = false;
      continue;
    }
    当前 += ch;
  }
  段.push({ text: 当前, quoted: 见过引号 });
  return 段
    .map(({ text, quoted }) => ({ v: unquote(text.trim()), quoted }))
    .filter(({ v, quoted }) => quoted || v !== '')
    .map(({ v }) => v);
}

/**
 * 去掉值的引号，并把**转义序列解回原字符**（W3 批3 起，批4 补 `\n`/`\r`/`\t`）。
 *
 * 引号里的 `\"` / `\'` / `\\` / `\n` 是转义写法：`"a \" b"` 的值是 `a " b`，不是 `a \" b`。
 * 只对**带引号的值**解转义——不带引号的值（例如 Windows 路径 `C:\Users\k`）原样保留，
 * 免得把反斜杠当转义吃掉（`\U` 不在转义集里，本来也留得住，但整条规则更清楚）。
 *
 * @param {string} value
 * @returns {string}
 */
function unquote(value) {
  const 带引号 = (value.startsWith('"') && value.endsWith('"') && value.length >= 2) || (value.startsWith("'") && value.endsWith("'") && value.length >= 2);
  if (!带引号) return value;
  return value.slice(1, -1).replace(/\\(["'\\nrt])/g, (_m, 码) => ({ n: '\n', r: '\r', t: '\t' }[码] ?? 码));
}

/**
 * 一个值**必须**引号化吗（W3 批4·2026-10-09）。
 *
 * 判据只有一条：**不引号化的话，读回来会不一样**。写侧此前从不引号化，于是
 * `名: 甲 # 乙` 落盘后再读回是 `甲`（`#` 被当行内注释切掉）、`摘要: # 标题式值` 读成空列表、
 * 首尾空白被吃掉、`"引号值"` 被 unquote 剥壳、`[x]` 被当数组——**全部静默**，errors 为空。
 *
 * 为什么不能一律引号化：出厂件要靠**字节比对**判断「有没有被改过」（升级层的判据），
 * 一律引号化会让每一件既有出厂文件当场漂移。所以只对「会读坏的值」动手，普通值逐字节不变。
 *
 * @param {string} s
 * @returns {boolean}
 */
function needsQuote(s) {
  if (s === '') return true; // 裸空值读回是 `[]`（数组），空串必须写成 `""`
  if (/^\s|\s$/.test(s)) return true; // 首尾空白会被 trim 掉
  if (/[\n\r]/.test(s)) return true; // 换行会把一行拆成两行
  if (s.startsWith('#')) return true; // 行首 `#` 被当整行注释
  if (/\s#/.test(s)) return true; // `#` 前有空白 ⇒ 行内注释的起点
  if (/["'\\]/.test(s)) return true; // 引号会被当引号边界剥壳；反斜杠会被当转义
  if (/^\[[\s\S]*\]$/.test(s)) return true; // 读侧把 `[...]` 当数组
  return false;
}

/** 引号化：转义 `\` 与 `"`，换行折成 `\n`（读侧 unquote 对称解回）。 */
function quoteValue(s) {
  return `"${String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r')}"`;
}

/**
 * 把对象元数据写成 front matter。键顺序固定，保证同一份内容两次写出字节一致
 * （升级层要靠字节比对判断「出厂有没有改」）。
 *
 * **写-读往返闭合**（W3 批4·2026-10-09）：需要时才引号化（见 `needsQuote`），
 * 数组**逐元素**判断（元素含逗号也必须引号化，否则读侧的数组切分会把它切成两个）——
 * 与读侧的 `unquote` / 数组切分对称。普通值（出厂件里那些 id/kind/authority…）
 * 一个字节都不动。
 *
 * @param {Record<string, any>} data
 * @returns {string}
 */
export function formatFrontMatter(data) {
  const order = ['id', 'kind', 'authority', 'zone', 'domain', 'project', 'version', 'generation', 'refs'];
  const keys = [...order.filter((k) => data[k] !== undefined), ...Object.keys(data).filter((k) => !order.includes(k)).sort()];
  const lines = keys.map((key) => {
    const value = data[key];
    if (Array.isArray(value)) {
      return `${key}: [${value
        .map((item) => {
          const s = String(item);
          // 数组元素多一条判据：逗号是分隔符，含逗号不引号化就会被切成两个元素。
          return needsQuote(s) || s.includes(',') ? quoteValue(s) : s;
        })
        .join(', ')}]`;
    }
    if (value === undefined) return `${key}:`;
    // null 显式落成 `null` 字面量（2026-10-14 审查 P3）：修前 null 与 undefined 同写成
    // 空值，读回来变 []（parseSimpleYaml 空值 ⇒ []）——null → [] 往返漂移。
    if (value === null) return `${key}: null`;
    const s = String(value);
    return `${key}: ${needsQuote(s) ? quoteValue(s) : s}`;
  });
  return `---\n${lines.join('\n')}\n---\n`;
}

/**
 * 解析一份对象文档。
 *
 * **入口归一换行**（W3 批2·2026-10-09）：此前 `source.startsWith('---\n')` 对 CRLF 文本
 * 判 false ⇒ front matter **整段不被识别**，`meta` 空、`body` 是全文，然后 `assertStructure`
 * 报「缺少 id」——真正的原因（换行符）在报错里一个字都看不到。
 * 现在统一折成 LF 再解析；写出侧仍是 LF，所以同一份内容两次写出的字节不变。
 *
 * @param {string} text 全文
 * @param {{ defaultAuthority?: string }} [options]
 * @returns {{
 *   meta: Record<string, any>,
 *   body: string,
 *   segments: Array<{ authority: string, heading: string|null, key: string, body: string, hash: string }>,
 *   authority: string,
 *   clauses: ReturnType<typeof splitClauses>,
 *   errors: string[],
 * }}
 */
export function parseDocument(text, options = {}) {
  // 先剥 BOM（2026-10-12 评审 P3）：UTF-8 BOM 会让 `startsWith('---\n')` 落空，
  // 整个 front matter 静默消失（元数据全丢、正文带着 `---` 残渣）。
  const source = String(text).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const fallback = options.defaultAuthority ?? '自治';
  const errors = [];
  let meta = {};
  let body = source;

  if (source.startsWith('---\n')) {
    const end = source.indexOf('\n---', 3);
    if (end === -1) {
      errors.push('front matter 未闭合');
    } else {
      const parsed = parseSimpleYaml(source.slice(4, end + 1));
      meta = parsed.data;
      errors.push(...parsed.errors);
      body = source.slice(end + 4).replace(/^\n/, '');
    }
  }

  const clauses = splitClauses(body);
  /** @type {Array<{ authority: string, heading: string|null, key: string, body: string, hash: string }>} */
  const segments = [];
  let current = { authority: fallback, heading: null, lines: [] };
  const flush = () => {
    const segBody = current.lines.join('\n').trim();
    if (segBody) {
      segments.push({
        authority: current.authority,
        heading: current.heading,
        key: current.heading ?? '@top',
        body: segBody,
        hash: clauseHashOf(clauses, current.heading) ?? '',
      });
    }
  };

  for (const line of body.split('\n')) {
    const marker = SEGMENT_MARKER.exec(line.trim());
    if (marker) {
      flush();
      current = { authority: marker[1], heading: null, lines: [] };
      continue;
    }
    if (/^#{1,6}\s+/.test(line)) {
      flush();
      current = { authority: current.authority, heading: line.replace(/^#{1,6}\s+/, '').trim(), lines: [] };
      continue;
    }
    current.lines.push(line);
  }
  flush();

  return {
    meta,
    body,
    segments,
    authority: highestAuthority(segments.map((s) => s.authority), fallback),
    clauses,
    errors,
  };
}

/** @param {ReturnType<typeof splitClauses>} clauses @param {string|null} heading */
function clauseHashOf(clauses, heading) {
  if (!heading) return null;
  return clauses.find((c) => c.heading === heading)?.hash ?? null;
}

/**
 * §11：正文结构是写入侧义务——写入时校验，不合规拒绝写入。
 *
 * 每类对象的「合规」定义在此表里，别处不再重复判断。
 * 事后修补会违反「不许改写只能追加」，所以这是唯一时机。
 */
const STRUCTURE_RULES = {  规则: { sections: [], meta: ['id', 'authority'], because: '规则必须带授权标签才能被策略引擎判定' },
  身份: { sections: ['个体L0', '个体L1'], meta: ['id'], because: '角色卡必须显式给出身份与个体规则两段' },
  能力: { sections: ['适用岗位', '怎么做'], meta: ['id'], because: '能力库装的是「怎么做」，且必须声明适用岗位以维持单源' },
  知识: { sections: ['正文'], meta: ['id', 'project', 'source'], because: '知识写入必带「谁记的 + 怎么知道的」，并恒打项目标签' },
  经历: { sections: ['正文'], meta: ['id', 'source'], because: '经历写入必带来源；只增不改' },
  偏好: { sections: ['正文'], meta: ['id', 'source'], because: '偏好属于部署且永不外流，写入必带来源' },
  作答: { sections: ['正文'], meta: ['id', 'source'], because: '作答归档需可追溯来源' },
  任务: { sections: ['判据'], meta: ['id'], because: '§7：验收标准必填，派发后判据冻结' },
  产物: { sections: [], meta: ['id'], because: '产物是对象存储里的实体，任务节点只存引用' },
  消息: { sections: [], meta: ['id'], because: '消息 authority = 只增' },
  账目: { sections: [], meta: ['id'], because: '账目只增' },
};

/**
 * 生效文档解析器（R18 · 审查 2026-10-16）：**唯一**的「私有叠加层 → 生效内容」解析落点。
 *
 * 修前的病（报告 R18）：解释词写着「部分副本叠加层、未改条款继承出厂」，运行态却是
 * **整文件替换**——`#loadRules` 找到私有文件就停止读出厂那份。于是私有文件只定制一段、
 * 其余段原样照抄时，出厂里那些**未被私有碰过**的条款（含授权块 grant）在生效面上消失：
 * 报告实证「出厂权限条款 deny、私有只定制无关段 ⇒ compare 给『直接替换』、compare+reload
 * 后限制实际消失、grants=[]、请求误 allow」。
 *
 * 本函数的语义（与 upgrade.compare 的条款级处置同源）：
 *  - 以出厂文档为底（缺出厂则空底）；
 *  - 私有文档里**出现的同名段**（按段 key 比对）覆盖出厂同名段；
 *  - 私有文档里**没出现的段**继承出厂；
 *  - 元数据（front matter）以私有为准（它是那份副本的身份），`body` 按合并后的段序重建；
 *  - policy块先脱离正文；grant按subject/action/authority/kind覆盖，未覆盖条款继承，其他块字段按键继承；
 *  - 同层同选择器保留首条，延续引擎first-match；空grants不删除出厂条款，坏块进入errors。
 *
 * 返回形状与 `parseDocument` 一致（meta/body/segments/authority/clauses/errors），
 * 于是策略加载、角色卡读取、对象读取三面可以**共用同一份**结果，不再各写一套覆盖口径。
 *
 * @param {string|null|undefined} 出厂文本
 * @param {string|null|undefined} 私有文本
 * @param {{ defaultAuthority?: string, 私有标为?: string, 出厂标为?: string }} [options]
 * @returns {ReturnType<typeof parseDocument> & { 合并来源: string }}
 */
export function effectiveDocument(出厂文本, 私有文本, options = {}) {
  const 出厂有 = typeof 出厂文本 === 'string' && 出厂文本.trim() !== '';
  const 私有有 = typeof 私有文本 === 'string' && 私有文本.trim() !== '';
  if (!出厂有 && !私有有) {
    const 空 = parseDocument('', options);
    空.errors = [...(空.errors ?? []), '两区都没有内容：生效文档无从解析'];
    return { ...空, 合并来源: '两区皆缺' };
  }
  if (!私有有) {
    return { ...parseDocument(String(出厂文本), options), 合并来源: options.出厂标为 ?? '出厂' };
  }
  if (!出厂有) {
    return { ...parseDocument(String(私有文本), options), 合并来源: options.私有标为 ?? '私有' };
  }

  // 授权块先脱离段正文：段覆盖不能吞掉未覆盖的grant，也不能让坏块被另一层遮住。
  const 出厂块 = extractPolicyBlock(出厂文本);
  const 私有块 = extractPolicyBlock(私有文本);
  const 出厂 = parseDocument(String(出厂文本).replace(POLICY_BLOCK, ''), options);
  const 私有 = parseDocument(String(私有文本).replace(POLICY_BLOCK, ''), options);
  出厂.errors.push(...(出厂块?.解析错误 ?? []).map((error) => `出厂授权块：${error}`));
  私有.errors.push(...(私有块?.解析错误 ?? []).map((error) => `私有授权块：${error}`));
  if (出厂.errors?.length || 私有.errors?.length) {
    // 任一侧解析不了就如实报错（调用方按各自口径抛）——不静默退回整文件替换：
    // 那正是本函数要治的「解释与运行态不符」。
    return { ...私有, errors: [...(私有.errors ?? []), ...(出厂.errors ?? [])], 合并来源: '解析失败' };
  }

  // 段级合并：以出厂段序为骨，私有同名段原位替换；私有独有段追加在后（保持稳定序）。
  const 私有段表 = new Map(私有.segments.map((s) => [s.key, s]));
  const 用过的 = new Set();
  const 段 = [];
  for (const 出段 of 出厂.segments) {
    const 替代 = 私有段表.get(出段.key);
    if (替代) {
      段.push(替代);
      用过的.add(出段.key);
    } else {
      段.push(出段);
    }
  }
  for (const 私段 of 私有.segments) {
    if (!用过的.has(私段.key) && !出厂.segments.some((s) => s.key === 私段.key)) 段.push(私段);
  }

  // body 按合并段序重建：段的 `body` 只含段正文（不含标题行），必须把标题补回来——
  // 否则 `section(body, '个体L2')` 之类的段读取器找不到段（实测：合并后能力引用读成空）。
  // 段外头（front matter 之后、首段之前的 H1 标题等）以私有为准、缺则取出厂——它是文档的
  // 标题位，不属于任何段；丢了会让「正文逐字来自私有那份」这类断言与真机阅读面失真。
  const 头 = 头部(私有).trim() ? 头部(私有) : 头部(出厂);
  const 段正文 = 段.map((s) => `${s.heading ? `## ${s.heading}\n` : ''}${s.body}`).join('\n');
  // 主权者裁决（2026-10-17）：只有完整选择器相同才算覆盖，空列表不是删除出厂限制的指令。
  // 保持出厂条款顺序；同选择器的私有条款原位替换，私有新增条款追加，不暗改first-match语义。
  const 授权 = { ...出厂块, ...私有块 };
  delete 授权.解析错误;
  if (出厂块?.grants || 私有块?.grants) {
    const 选择器 = (grant) => JSON.stringify([grant.subject, grant.action, grant.authority || null, grant.kind || null]);
    const 条款表 = new Map();
    for (const grant of 出厂块?.grants ?? []) {
      const key = 选择器(grant);
      if (!条款表.has(key)) 条款表.set(key, grant);
    }
    const 私有已见 = new Set();
    for (const grant of 私有块?.grants ?? []) {
      const key = 选择器(grant);
      if (!私有已见.has(key)) 条款表.set(key, grant);
      私有已见.add(key);
    }
    授权.grants = [...条款表.values()];
  }
  const 授权块 = 出厂块 || 私有块 ? `\n\`\`\`policy\n${JSON.stringify(授权, null, 2)}\n\`\`\`\n` : '';
  const body = `${头}${段正文}${授权块}`.replace(/^\n+/, '');
  const 合并 = parseDocument(body, { ...options, defaultAuthority: 私有.meta?.authority ?? 出厂.meta?.authority ?? options.defaultAuthority });
  return {
    ...合并,
    meta: { ...出厂.meta, ...私有.meta },
    segments: 段,
    clauses: splitClauses(body),
    authority: AUTHORITY_OF(段, options.defaultAuthority),
    合并来源: `${options.出厂标为 ?? '出厂'}+${options.私有标为 ?? '私有'}（段级合并）`,
  };
}

/** 段外头：front matter 之后、首个 `##` 段标题之前的正文（H1 标题等）。 */
function 头部(doc) {
  const body = String(doc?.body ?? '');
  const 首段 = body.search(/^##\s/m);
  return 首段 === -1 ? body : body.slice(0, 首段);
}

const POLICY_BLOCK = /```policy\r?\n([\s\S]*?)```/g;

/**
 * 授权块的唯一JSON解析处；所有块都参与校验，坏块不能因叠加覆盖而消失。
 * @param {string} body 文档正文或完整源文本
 * @returns {{ grants?: object[], roles?: string[], mode?: string, 解析错误: string[] }|null} 无块返回null；错误由调用方fail-closed。
 */
export function extractPolicyBlock(body) {
  const source = String(body);
  const blocks = [...source.matchAll(POLICY_BLOCK)];
  const 开始数 = [...source.matchAll(/```policy(?:\r?\n|$)/g)].length;
  if (blocks.length === 0 && 开始数 === 0) return null;
  const merged = {};
  const 解析错误 = blocks.length === 开始数 ? [] : ['policy 授权块未闭合。'];
  blocks.forEach(([, raw], index) => {
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      解析错误.push(`\`\`\`policy 块 #${index + 1} 不是合法 JSON：${error instanceof Error ? error.message : String(error)}`);
      return;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      解析错误.push(`\`\`\`policy 块 #${index + 1} 必须是 JSON 对象，收到 ${Array.isArray(parsed) ? '数组' : typeof parsed}`);
      return;
    }
    if (Object.hasOwn(parsed, 'grants')) {
      if (!Array.isArray(parsed.grants)) {
        解析错误.push(`policy 块 #${index + 1} 的 grants 必须是数组。`);
        return;
      }
      parsed.grants.forEach((grant, i) => {
        if (!grant || typeof grant !== 'object' || Array.isArray(grant)) {
          解析错误.push(`policy 块 #${index + 1} grant#${i + 1} 必须是对象。`);
          return;
        }
        for (const field of ['subject', 'action']) {
          if (typeof grant[field] !== 'string' || !grant[field].trim()) 解析错误.push(`grant#${i + 1} 缺 ${field} 或不是非空字符串。`);
        }
        if (!['allow', 'deny', 'confirm'].includes(grant.verdict ?? 'allow')) 解析错误.push(`grant#${i + 1} 的 verdict 非法：${JSON.stringify(grant.verdict)}。`);
      });
    }
    for (const key of Object.keys(parsed)) {
      // 配置键不许触发Object.prototype上的setter。
      const value = Array.isArray(parsed[key]) ? [...(Object.hasOwn(merged, key) ? merged[key] : []), ...parsed[key]] : parsed[key];
      Object.defineProperty(merged, key, { value, enumerable: true, writable: true, configurable: true });
    }
  });
  merged.解析错误 = 解析错误;
  return merged;
}

/** 段内最高授权（合并文档的整体 authority；缺段时回退 fallback）。 */
function AUTHORITY_OF(段, fallback = '自治') {
  try {
    return highestAuthority(段.map((s) => s.authority), fallback);
  } catch {
    return fallback;
  }
}

/**
 * @param {string} kind
 * @param {ReturnType<typeof parseDocument>} doc
 * @throws {InvalidBody}
 */
export function assertStructure(kind, doc) {
  const rule = STRUCTURE_RULES[kind];
  if (!rule) throw new InvalidBody(`未知的 kind：${kind}`, { detail: { kind } });
  // 封闭清单要被真的执行，而不是当注释：新增一个 kind 就必须同时给出结构规则。
  if (!KINDS.includes(kind)) throw new InvalidBody(`kind=${kind} 不在 §6 的封闭清单里`, { detail: { 清单: KINDS } });  if (doc.errors.length) {
    throw new InvalidBody(`元数据无法解析：${doc.errors.join('；')}`, { detail: { errors: doc.errors } });
  }
  const missingMeta = rule.meta.filter((key) => doc.meta[key] === undefined || doc.meta[key] === '');
  const headings = doc.clauses.map((c) => c.heading);
  const missingSections = rule.sections.filter((name) => !headings.some((h) => h.includes(name)));
  if (missingMeta.length || missingSections.length) {
    throw new InvalidBody(
      `${kind} 正文结构不合规：${rule.because}。缺少 ${[...missingMeta, ...missingSections].join('、')}`,
      { missing: [...missingMeta, ...missingSections], detail: { kind, rule: rule.because } },
    );
  }
  if (kind === '规则' && !AUTHORITIES.includes(doc.meta.authority)) {
    throw new InvalidBody(`规则对象的 authority 必须是宪章/法律/自治之一，收到：${doc.meta.authority}`);
  }
}
