import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fakeHost, fakeExec } from '../dsh-mind/test/host-harness.mjs';
import { apply } from '../dsh-mind/components/kernel/lib/index.js';
import { shareOrg } from '../dsh-mind/src/runtime.js';
import { Org } from '../dsh-mind/src/org.js';
import { runAction } from '../dsh-mind/lib/actions.js';
const root = fileURLToPath(new URL(`./host-${Date.now()}/`, import.meta.url));
const factoryRoot = fileURLToPath(new URL('../dsh-mind/mind/', import.meta.url));
const lead = { id: 'lead', kind: 'Lead' };
const result = {};
async function until(check) {
  const end = Date.now() + 3000;
  for (;;) { if (await check()) return; if (Date.now() > end) throw new Error('Expected async observation timed out'); await new Promise(r => setTimeout(r, 20)); }
}
{
  const spec = { home: root + 'events', privateRoot: root + 'events/private', factoryRoot, project: 'p' };
  const org = await shareOrg(spec), host = fakeHost();
  await apply(host.ctx, spec);
  const old = new Date(Date.now() - 10 * 86400000).toISOString();
  await org.registry.markInteraction({ at: old, 来源: '部署引导' });
  // The supported markInteraction API may not take an `at` parameter, so seed only this isolated identity.
  const identity = await org.registry.identity();
  await writeFile(org.layout.identityFile(), JSON.stringify({ ...identity, sovereign: { ...identity.sovereign, lastInteraction: old } }));
  await org.policy.reload();
  assert.equal(org.policy.presence().lost, true);
  host.触发('session/event', { id: 'automated-child', header: { origin: 'subagent', delegationDepth: 1 } }, { type: 'user/message', source: { kind: 'plugin', plugin: 'runtime-context' }, content: [{ type: 'text', text: 'automated runtime context' }] });
  await until(async () => (await org.registry.identity()).sovereign.lastInteraction !== old);
  result.automatedUserEvent = { beforeLost: true, afterLost: org.policy.presence().lost, lastInteraction: (await org.registry.identity()).sovereign.lastInteraction };
  const exec = fakeExec({ name: 'write', sessionId: 'audit-child' });
  host.触发('tools/result', exec, { isError: false });
  const session = exec.agent.session;
  host.触发('session/event', session, { type: 'turn/end' });
  await new Promise(r => setTimeout(r, 50));
  const before = (await org.audit.read({})).filter(row => row.动作 === '工具调用成功').length;
  host.触发('turn/end', { agent: exec.agent });
  await until(async () => (await org.audit.read({})).some(row => row.动作 === '工具调用成功'));
  const after = (await org.audit.read({})).filter(row => row.动作 === '工具调用成功').length;
  assert.equal(before, 0); assert.equal(after, 1);
  result.realTurnEventVersusSynthetic = { officialSessionEventSummaries: before, syntheticBareEventSummaries: after };
  host.清理();
}
{
  const org = await Org.open({ home: root + 'freshness', privateRoot: root + 'freshness/private', factoryRoot, project: 'p' });
  const target = { id: 'freshness-artifact', kind: '产物', authority: '自治', zone: '私有' };
  const evaluate = () => org.policy.decide({ subject: lead, action: 'write', target });
  const baseline = await evaluate(); assert.equal(baseline.verdict, 'allow');
  const original = org.layout.factoryDefault.bind(org.layout); let once = false;
  org.layout.factoryDefault = function (name) {
    if (name === '介入度' && !once) {
      once = true;
      const path = org.layout.rulePath('权限矩阵', '私有'); mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, '---\nid: 权限矩阵\nkind: 规则\nauthority: 法律\nzone: 私有\ndomain: 集体\nversion: 1\n---\n# 权限矩阵\n\n## 机器可读授权块\n```policy\n' + JSON.stringify({ grants: [{ subject: 'Lead', action: 'write', kind: '产物', authority: '自治', verdict: 'deny', reason: 'new human restriction' }] }) + '\n```\n');
    }
    return original(name);
  };
  await org.policy.reload(); org.layout.factoryDefault = original;
  const stale = await evaluate(), freshness = await org.policy.refreshIfStale();
  await org.policy.reload(); const reread = await evaluate();
  assert.equal(stale.verdict, 'allow'); assert.equal(freshness.changed, false); assert.equal(reread.verdict, 'deny');
  result.ruleReadStatRace = { baseline, afterConcurrentRestriction: stale, refreshIfStale: freshness, afterExplicitReload: reread };
}
{
  const org = await Org.open({ home: root + 'role-revoke', privateRoot: root + 'role-revoke/private', factoryRoot, project: 'p' });
  const member = { id: 'member-a', kind: '成员' };
  await org.registry.assign({ subject: lead, 岗位: '插件工程', 实例: member.id });
  const task = await org.tasks.create({ subject: lead, 项目: 'p', 描述: 'revoked role writer', 负责人: [member.id], 判据: ['probe'] });
  await org.tasks.dispatch(task.id, { subject: lead, 项目: 'p' }); await org.tasks.start(task.id, { subject: member, 项目: 'p' });
  await org.registry.revoke({ subject: { id: 'human', kind: '主权者' }, 对象id: '插件工程', 理由: 'stop this role' });
  const response = await runAction({ org, 项目: 'p', 主体: member, args: { action: 'memory_write', 任务: task.id, 类: '知识', 内容: 'role remains writable', 来源: 'revoked role probe' } });
  assert.ok(response.条目?.id || response.记忆?.id || response.id || response);
  result.revokedRoleMemberWrite = { roleRevoked: true, response };
}
await writeFile(new URL('./host-policy-evidence.json', import.meta.url), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
